# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# from llm_utils import get_llm_response
# from memory_agent import MemoryAgent
# from weather_utils import get_weather

# # # app = FastAPI()

# # # class UserPreferences(BaseModel):
# # #     user_name: str
# # #     city: str
# # #     start_time: str
# # #     end_time: str
# # #     budget: float
# # #     interests: list

# # # # Initialize the Memory Agent
# # # memory_agent = MemoryAgent("bolt://localhost:7687", "neo4j", "password")

# # # @app.post("/generate_itinerary")
# # # async def generate_itinerary(preferences: UserPreferences):
# # #     try:
# # #         # Store user preferences in the memory database
# # #         memory_agent.store_memory(preferences.user_name, "INTERESTS", preferences.interests)
        
# # #         # Generate a response using the LLM for an itinerary
# # #         llm_response = get_llm_response(f"Plan a one-day itinerary in {preferences.city} considering the interests: {preferences.interests}")
        
# # #         # Get weather information for the city
# # #         weather_info = get_weather(preferences.city)
        
# # #         return {
# # #             "itinerary": llm_response,
# # #             "weather": weather_info
# # #         }
# # #     except Exception as e:
# # #         raise HTTPException(status_code=500, detail=str(e))

# # # # Close the memory agent connection when the app shuts down
# # # @app.on_event("shutdown")
# # # def shutdown_event():
# # #     memory_agent.close()

# # from fastapi import FastAPI, HTTPException
# # from pydantic import BaseModel
# # import logging
# # from llm_utils import get_llm_response
# # from memory_agent import MemoryAgent
# # from weather_utils import get_weather

# # # Configure logging
# # logging.basicConfig(level=logging.INFO)

# # app = FastAPI()

# # class UserPreferences(BaseModel):
# #     user_name: str
# #     city: str
# #     start_time: str
# #     end_time: str
# #     budget: float
# #     interests: list

# # # Initialize the Memory Agent (assuming memory_agent.py is correctly implemented)
# # memory_agent = MemoryAgent("bolt://localhost:7687", "neo4j", "password")

# # @app.post("/generate_itinerary")
# # async def generate_itinerary(preferences: UserPreferences):
# #     try:
# #         # Log received user preferences
# #         logging.info("Received user preferences: %s", preferences)
        
# #         # Store user preferences in the memory database
# #         memory_agent.store_memory(preferences.user_name, "INTERESTS", preferences.interests)
        
# #         # Generate a response using the LLM for an itinerary
# #         llm_response = get_llm_response(f"Plan a one-day itinerary in {preferences.city} considering the interests: {preferences.interests}")
        
# #         if not llm_response:
# #             raise ValueError("No response from LLM")
        
# #         # Get weather information for the city
# #         weather_info = get_weather(preferences.city)
        
# #         if "error" in weather_info:
# #             logging.warning("Weather API returned an error: %s", weather_info["error"])
        
# #         return {
# #             "itinerary": llm_response,
# #             "weather": weather_info
# #         }
# #     except Exception as e:
# #         logging.error("An error occurred: %s", str(e))
# #         raise HTTPException(status_code=500, detail="Internal server error occurred")

# # # Close the memory agent connection when the app shuts down
# # @app.on_event("shutdown")
# # def shutdown_event():
# #     memory_agent.close()
# import json

# def save_memory_to_file(user_name, preferences):
#     try:
#         with open("user_memory.json", "r") as file:
#             data = json.load(file)
#     except FileNotFoundError:
#         data = {}

#     data[user_name] = preferences

#     with open("user_memory.json", "w") as file:
#         json.dump(data, file)

# @app.post("/generate_itinerary")
# async def generate_itinerary(preferences: UserPreferences):
#     try:
#         # Save preferences to a file
#         save_memory_to_file(preferences.user_name, {
#             "city": preferences.city,
#             "interests": preferences.interests,
#             "budget": preferences.budget
#         })
        
#         llm_response = get_llm_response(f"Plan a one-day itinerary in {preferences.city} considering the interests: {preferences.interests}")
        
#         if not llm_response:
#             raise ValueError("No response from LLM")
        
#         weather_info = get_weather(preferences.city)
        
#         return {
#             "itinerary": llm_response,
#             "weather": weather_info
#         }
#     except Exception as e:
#         logging.error("An error occurred: %s", str(e))
#         raise HTTPException(status_code=500, detail="Internal server error occurred")

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import logging
from llm_utils import get_llm_response
from weather_utils import get_weather
from memory_utils import save_memory_to_file  # Import from your custom memory utility

# Configure logging
logging.basicConfig(level=logging.INFO)

app = FastAPI()

class UserPreferences(BaseModel):
    user_name: str
    city: str
    start_time: str
    end_time: str
    budget: float
    interests: list

@app.post("/generate_itinerary")
async def generate_itinerary(preferences: UserPreferences):
    try:
        # Save user preferences to file
        save_memory_to_file(preferences.user_name, {
            "city": preferences.city,
            "interests": preferences.interests,
            "budget": preferences.budget
        })
        
        # Generate a response using the LLM
        llm_response = get_llm_response(f"Plan a one-day itinerary in {preferences.city} considering the interests: {preferences.interests}")
        
        if not llm_response:
            raise ValueError("No response from LLM")
        
        # Get weather information for the city
        weather_info = get_weather(preferences.city)
        
        return {
            "itinerary": llm_response,
            "weather": weather_info
        }
    except Exception as e:
        logging.error("An error occurred: %s", str(e))
        raise HTTPException(status_code=500, detail="Internal server error occurred")
